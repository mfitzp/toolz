There are two types of files in this pack; all files are needed.

1. m-files for the beam search heuristics
2. Sample data and an m-file for the running the sample data 

File list -----------------------------------------------------------------------

1. m-files for the fast heuristics
- fastpa.zip (fastpa.m, beamsearch.m, evaluate.m, coco.m)

2. Sample data and an m-file for the running the sample data 
- sample.zip (sample.txt, dotest.m)
------------------------------------------------------------------------------


Usage -----------------------------------------------------------------------
* After execution, the output value (correlation coefficient between overall f and r) is added in "output.txt" text file and the computation time value is added in "etime.txt" text file.


1. Beam search heuristics

[fspek,optima]=fastpa(f,r,s,ra1,ra2,option, fig)
	
INPUT:		f	-	Spectra to be shift corrected
		r	-	Reference spectra
				(f and r must be of the same length)
		s	-	number of segments to devide spectra in
		ra1	-	max range of sideway movements, [-ra1 ra1]
		ra2	-	max range of interpolation, [-ra2 ra2]
		option	-	if 1, beam width = 1
				else if 2, beam width  = 2
		fig 	-	fig = 1 draws the result

OUTPUT:		fspek    	-	shift corrected spectra
		optima	-	The optimal phasing parameters

SUBROUTINES:	beamsearch.m, evaluate.m, coco.m

TO RUN EXAMPLE :	Type 'dotest' and enter.

-----------------------------------------------------------------------------------

